package com.example.HealthAndFitnessPlatform.exception;

public class IngredientNotFoundException extends RuntimeException {

        public IngredientNotFoundException(String msg){
            super(msg);
        }
}
