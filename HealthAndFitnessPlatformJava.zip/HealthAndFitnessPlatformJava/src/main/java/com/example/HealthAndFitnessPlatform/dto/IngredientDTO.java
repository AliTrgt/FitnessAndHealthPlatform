package com.example.HealthAndFitnessPlatform.dto;

import lombok.Data;

import java.util.List;

@Data
public class IngredientDTO {

    private int id;
    private String name;
    private int quantity;

}
