package com.example.HealthAndFitnessPlatform.exception;


public class RecipeNotFoundException extends RuntimeException {

    public RecipeNotFoundException(String msg){
                super(msg);
    }

}
