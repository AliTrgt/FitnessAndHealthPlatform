package com.example.HealthAndFitnessPlatform.dto;

import lombok.Data;

@Data
public class BmiUpdateRequest {
    private double newValue;
}
