package com.example.HealthAndFitnessPlatform.dto;

public record AuthRequest(
        String username,
        String password
) {
}
